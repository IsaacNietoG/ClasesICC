
public class ClaseString {
	
	public static void main(String[] args) {

		String cadena = "Hola mundo";
		int x=10;


		System.out.println(cadena.charAt(0));
		System.out.println(cadena.length());
		System.out.println(cadena.indexOf("l"));
		System.out.println(cadena.toLowerCase());	



	}



} 
