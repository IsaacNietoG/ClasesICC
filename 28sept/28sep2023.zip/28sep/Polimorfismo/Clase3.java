public class Clase3 extends Clase2{
	@Override
	public void mensaje(){
		//super.mensaje();
		System.out.println("Adiós mundo, 3a clase");
	}
}