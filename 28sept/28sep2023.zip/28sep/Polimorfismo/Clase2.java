public class Clase2 extends Clase1{
	@Override
	public void mensaje(){
		System.out.println("Buen día mundo, 2a clase");
	}
}