public class Clase1{
	public void mensaje(){
		System.out.println("Hola mundo, 1a clase");
	}
}