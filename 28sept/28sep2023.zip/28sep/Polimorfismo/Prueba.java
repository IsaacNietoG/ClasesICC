public class Prueba{
	public static void main(String[] args){
		Clase3 c3 = new Clase3();
		c3.mensaje();
	}
}