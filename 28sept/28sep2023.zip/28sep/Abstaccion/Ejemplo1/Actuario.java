/**
 * Clase que extiende de la clase abstracta.
 */
class Actuario extends Abstracto{
    /**
     * Implementamos código al método abstracto.
     */
    public void aprobado(){
        System.out.println("El actuario no aprobó :'0");
    }
}