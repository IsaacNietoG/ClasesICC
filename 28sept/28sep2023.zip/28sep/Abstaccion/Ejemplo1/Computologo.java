/**
 * Clase que extiende de la clase abstracta.
 */
class Computologo extends Abstracto{
    /**
     * Implementamos código al método abstracto.
     */
    public void aprobado(){
        System.out.println("El computólogo sí aprobó, guapo");
    }
}